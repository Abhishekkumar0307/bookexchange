const express = require('express');
const router = express.Router();

// FIX: Ensure this import points to the correct file
const { getAllEvents } = require('../controllers/eventController');

router.get('/', getAllEvents);

module.exports = router;
