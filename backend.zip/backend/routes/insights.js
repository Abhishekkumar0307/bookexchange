const express = require('express');
const { getUserInsights } = require('../controllers/insightController');
const router = express.Router();

router.get('/:userId', getUserInsights);

module.exports = router;
