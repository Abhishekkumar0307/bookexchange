const express = require('express');
const { searchBooks, getTrendingBooks } = require('../controllers/bookController');
const router = express.Router();

router.get('/search', searchBooks);
router.get('/trending', getTrendingBooks);

module.exports = router;
