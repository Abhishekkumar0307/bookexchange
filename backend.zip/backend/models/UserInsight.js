const mongoose = require('mongoose');

const userInsightSchema = new mongoose.Schema({
  userId: String,
  booksRead: Number,
  avgRating: Number,
  mostPopularGenre: String,
});

module.exports = mongoose.model('UserInsight', userInsightSchema);
