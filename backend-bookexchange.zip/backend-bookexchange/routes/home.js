const express = require("express");
const router = express.Router();

router.get('/', (req, res) => {
  res.json([
    { title: "The Crash", author: "John Doe", price: "$12.00" },
    { title: "Strangers in Time", author: "Jane Smith", price: "$15.00" }
  ]);
});

module.exports = router;
