require('dotenv').config();  
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Signup Route
router.post('/signup', async (req, res) => {
  try {
     const { name, email, password,location } = req.body;
    console.log(" Signup request received:", { name, email,location});

    const hashed = await bcrypt.hash(password, 10);
  const user = await User.create({ name, email, password: hashed ,location});
    console.log(" User signed up:", user._id);
    res.json({ user });
  } catch (err) {
    console.error(" Signup failed:", err.message);
    res.status(500).json({ error: 'Signup failed', detail: err.message });
  }
});

// Login Route
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log("Login attempt:", email);

    const user = await User.findOne({ email });
    if (!user) {
      console.warn("Email not found:", email);
      return res.status(401).send('Invalid credentials');
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.warn("Invalid password for:", email);
      return res.status(401).send('Invalid credentials');
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
    console.log(" Login successful for:", user._id);
    res.json({ token });
  } catch (err) {
    console.error(" Login failed:", err.message);
    res.status(500).json({ error: 'Login failed', detail: err.message });
  }
});

module.exports = router;
