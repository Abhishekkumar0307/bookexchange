const express = require("express");
const router = express.Router();
const Book = require("../models/Book");

// 🔍 SEARCH route with q / author / title
router.get("/search", async (req, res) => {
  const { q, author, title } = req.query;

  try {
    const query = [];

    if (q) {
      query.push(
        { title: { $regex: q, $options: "i" } },
        { author: { $regex: q, $options: "i" } }
      );
    }

    if (author) {
      query.push({ author: { $regex: author, $options: "i" } });
    }

    if (title) {
      query.push({ title: { $regex: title, $options: "i" } });
    }

    const books = await Book.find({
      $or: query.length > 0 ? query : [{}]
    });

    res.json(books);
  } catch (err) {
    console.error("Search error:", err); // Helps in debugging
    res.status(500).json({ error: "Server Error" });
  }
});

// ➕ ADD route
router.post("/add", async (req, res) => {
  const { title, author } = req.body;
  try {
    const newBook = new Book({ title, author });
    await newBook.save();
    res.status(201).json(newBook);
  } catch (err) {
    console.error("Add book error:", err);
    res.status(500).json({ error: "Failed to add book" });
  }
});

module.exports = router;
