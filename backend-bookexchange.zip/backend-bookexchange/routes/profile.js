const express = require("express");
const router = express.Router();
const User = require("../models/User");


router.get("/:email", async (req, res) => {
  try {
    const user = await User.findOne({ email: req.params.email });
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
});


router.post("/", async (req, res) => {
  const { name, email, password, location } = req.body;
  try {
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already exists" });

    const newUser = new User({ name, email, password, location });
    await newUser.save();
    res.status(201).json({ message: "Profile created", user: newUser });
  } catch (err) {
    res.status(500).json({ error: "Error creating profile" });
  }
});

module.exports = router;
