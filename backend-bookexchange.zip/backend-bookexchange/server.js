const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
require('dotenv').config(); // Load .env if needed

// Route imports
const bookRoutes = require("./routes/books");
const profileRoutes = require("./routes/profile");
const homeRoutes = require("./routes/home");

const app = express(); 

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect("mongodb://localhost:27017/bookexchange", {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log("MongoDB connected"))
  .catch(err => console.error(" MongoDB connection failed:", err));

// Route handling
app.use("/api/books", bookRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api/home", homeRoutes);

// Start server
app.listen(5000, () => console.log("Server started on port 5000"));
